public interface    ATMState {
    void handle(ATM atm);
}
