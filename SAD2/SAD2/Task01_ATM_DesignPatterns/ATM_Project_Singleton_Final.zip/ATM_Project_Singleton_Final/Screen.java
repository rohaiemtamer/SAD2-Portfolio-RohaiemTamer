public class Screen {

    public void displayMessage(String message) {
        System.out.println(message);
    }
}
