public class ATMCard {

    private String cardNumber;

    public ATMCard(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }
}
